from setuptools import setup
setup(name='floodsystem',
      version='0.1',
      description='CUED Part IA flood warning system exercise',
      packages=['floodsystem'],
      )
